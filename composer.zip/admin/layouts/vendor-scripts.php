<!-- JAVASCRIPT -->
<script src="../ajax/jquery.js"></script>
<script src="../assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../assets/libs/metismenujs/metismenujs.min.js"></script>
<script src="../assets/libs/simplebar/simplebar.min.js"></script>
<script src="../assets/libs/feather-icons/feather.min.js"></script>
<!-- choices js -->
<script src="../assets/libs/choices.js/public/assets/scripts/choices.min.js"></script>

<script src="../assets/libs/alertifyjs/build/alertify.min.js"></script>

<!-- Sweet Alerts js -->
<script src="../assets/libs/sweetalert2/sweetalert2.min.js"></script>
